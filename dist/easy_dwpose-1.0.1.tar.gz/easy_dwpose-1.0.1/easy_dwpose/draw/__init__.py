from .openpose import draw_pose as draw_openpose

__all__ = ["draw_openpose"]
