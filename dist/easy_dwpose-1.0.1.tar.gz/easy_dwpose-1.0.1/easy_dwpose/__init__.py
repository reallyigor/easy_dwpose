from easy_dwpose.dwpose import DWposeDetector

__all__ = ["DWposeDetector"]
